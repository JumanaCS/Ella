import React from "react";
import { Text, StyleSheet, View, Image, TouchableOpacity } from "react-native";

//bottom bar (rectangle), "closet and outfits" button, "camera" button, "profile" button

const TopBarComp = (props) => {


  return (
    
  <View>
    
    <Image style={styles.bar} source={require('../../assets/contact.png')} />

    <TouchableOpacity onPress={ props.phoneNav }>
        <Image style={styles.image} source={require('../../assets/call.png')} />
    </TouchableOpacity>

  </View>

  );
};


const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderTopWidth: 2,
        paddingVertical: 10,
        paddingBottom: 30,
        marginTop: 20,
        gap: 70,
        borderColor: "#193625",
        backgroundColor: '#DAE7E0'
    },
    camera: {
        height: 50,
        width: 50,
    },
    image: {
        position: "absolute",
        resizeMode: "contain",
        width: 65,
        height: 65,
        top: 75,
        left: 300,
    },
    bar: {
        position: "absolute",
        resizeMode: "contain",
        width: 400,
        height: 100,
        right: 0,
        top: 60,
    }
});

export default TopBarComp;
