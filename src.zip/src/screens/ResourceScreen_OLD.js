import React, {useState} from "react";
import { Text, StyleSheet, View, Image, TextInput, ScrollView } from "react-native";
import NavBarComp from "../components/NavBarComp";
import TopBarComp from "../components/TopBarComp";
import TextBoxComp from "../components/TextBoxComp";


const ResourceScreen = (props) => {

  const [text, setText] = useState('');
  const [height, setHeight] = useState(40);

  return (
      <View style={{flex: 1}}>



          <Text style={[styles.title, {top: 120, left: 20}]}>Emergency Check-in</Text>
          <Text style={[styles.subtitle, {top: 170, left: 20}]}>Contact's Name</Text>

          <TextBoxComp></TextBoxComp>

          <Text style={[styles.subtitle, {top: 210, left: 20}]}>Contact's Phone</Text>
          <Text style={[styles.subtitle, {top: 250, left: 20}]}>Message to send</Text>



        <NavBarComp isMap="false" isPersonal="false" isResources="true"
                    navBarPosition = {styles.navBarPosition}
                    onPressPersonal={() => {props.navigation.navigate("Personal")}}
                    onPressMap={() => {props.navigation.navigate("Map")}}/>
  
      </View>
  
    );
};

const styles = StyleSheet.create({
  title: {
    fontSize: 30,
    position: "absolute"
  },
  subtitle: {
    fontSize: 20,
    position: "absolute"
  },
  navBarPosition: {
    top: 704,
  },
  flexBox: {
    flex: 1
  },
  container: {
    padding: 10,
    position: "absolute"
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    fontSize: 16,
  },
});

export default ResourceScreen;
