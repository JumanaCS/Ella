import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Font from 'expo-font';

const ReportFormScreen = (props) => {
  const [publicAnswers, setPublicAnswers] = useState({
    q1: '',
    q2: '',
    q3: '',
    q4: '',
  });

  const [privateAnswers, setPrivateAnswers] = useState({
    q1: '',
    q2: '',
    q3: '',
    q4: '',
  });

  const [showPrivateFields, setShowPrivateFields] = useState({
    q1: false,
    q2: false,
    q3: false,
    q4: false,
  });

  const [fontsLoaded, setFontsLoaded] = useState(false);

  // Load custom fonts
  React.useEffect(() => {
    const loadAppFonts = async () => {
      try {
        await Font.loadAsync({
          'HappyChicken': require('../../assets/fonts/Happy_Chicken.ttf'),
          'Summery': require('../../assets/fonts/Summary_Notes.ttf')
        });
        setFontsLoaded(true);
      } catch (error) {
        console.error('Error loading fonts:', error);
      }
    };

    loadAppFonts();
  }, []);

  const handlePublicAnswerChange = (question, text) => {
    setPublicAnswers({
      ...publicAnswers,
      [question]: text,
    });
  };

  const handlePrivateAnswerChange = (question, text) => {
    setPrivateAnswers({
      ...privateAnswers,
      [question]: text,
    });
  };

  const togglePrivateField = (question) => {
    setShowPrivateFields({
      ...showPrivateFields,
      [question]: !showPrivateFields[question],
    });
  };

  const publicQuestions = [
    { id: 'q1', question: 'What do you remember about your experience?' },
    { id: 'q2', question: 'Can you describe the person/people who did this to you?        Did they have any distinguishing features?' },
    { id: 'q3', question: 'What was/were the perpetrator(s) wearing?' },
    { id: 'q4', question: 'What did the perpetrator(s) look like? (Race, hair color, etc.)' },
    { id: 'q5', question: 'What happened before and after the incident?' },
  ];

  const privateQuestions = [
    { id: 'q1', question: 'Do you have any evidence relating to the incident?' },
    { id: 'q2', question: 'Do you have any injuries, pain, or soreness?' },
    { id: 'q3', question: 'How long ago did this happen?' },
    { id: 'q4', question: 'Were there any witnesses?' },
    { id: 'q5', question: 'Is there anything else you would like to add?' },
  ];

  if (!fontsLoaded) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: '#fef8e9' }]}>
        <Text>Loading app...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: '#fef8e9'}]}>

      <ScrollView contentContainerStyle={[styles.contentContainer, { padding: 20 }]}>
        <View style={{padding: 20}}>

        <Image style = {[styles.formType, { top: 40, left: -128}]} source={require('../../assets/SV.png')}></Image>
        <Image style = {[styles.formType, { top: 40, left: 60}]} source={require('../../assets/PV.png')}></Image>

        </View>

      
        {/* Back button in top left corner */}
      <TouchableOpacity 
        style={styles.backButton} 
        onPress={() => props.navigation.navigate('Map')}
      >
        <Image 
          style={styles.backImage} 
          source={require('../../assets/back.png')} 
        />
      </TouchableOpacity>
      
        {/* Public Section */}
        <Text style={[styles.title, { 
          color: '#9b8cb1' 
        }]}>Report Form</Text>
        
        <Text style={[styles.subtitle, { 
          color: '#666'
        }]}>
          Please note: This report is public but completely anonymous
        </Text>
        
        <View style={[styles.separator, { 
          backgroundColor: '#ddd' 
        }]} />

        {publicQuestions.map((item) => (
          <View key={item.id} style={styles.questionContainer}>
            <Text style={[styles.questionText, { 
              color: '#9b8cb1' 
            }]}>{item.question}</Text>
            <TextInput
              style={[styles.input, { 
                borderColor: '#ddd' ,
                color: '#333',
                placeholderTextColor: '#999' 
              }]}
              multiline
              value={publicAnswers[item.id]}
              onChangeText={(text) => handlePublicAnswerChange(item.id, text)}
              placeholder="Type your answer here..."
            />
          </View>
        ))}

        {/* Private Section */}
        <View style={[styles.sectionSeparator, { 
          backgroundColor: '#aaa' 
        }]} />
        
        <Text style={[styles.sectionTitle, { 
          color: '#9b8cb1'
        }]}>More Detail</Text>

        <Text style={[styles.subtitle, { 
          color: '#666' 
        }]}>
          Below are some questions you might be asked when filing a police report.
        </Text>
        
        <Text style={[styles.subtitle, { 
          color: '#666' 
        }]}>
          Please note: This section is hidden from the public and can only be seen by you in your Journal Entry screen
        </Text>
        
        <View style={[styles.separator, { 
          backgroundColor: '#ddd' 
        }]} />

        {privateQuestions.map((item) => (
          <View key={`private-${item.id}`} style={styles.questionContainer}>
            <Text style={[styles.questionText, { 
              color: '#9b8cb1' 
            }]}>{item.question}</Text>
            {!showPrivateFields[item.id] ? (
              <TouchableOpacity
                style={[styles.answerButton, { 
                  backgroundColor: '#9b8cb1' 
                }]}
                onPress={() => togglePrivateField(item.id)}
              >
                <Text style={[styles.answerButtonText, { 
                  color: 'white' 
                }]}>Answer</Text>
              </TouchableOpacity>
            ) : (
              <TextInput
                style={[styles.input, { 
                  borderColor: '#ddd' ,
                  color: '#333' ,
                  placeholderTextColor: '#999' 
                }]}
                multiline
                value={privateAnswers[item.id]}
                onChangeText={(text) => handlePrivateAnswerChange(item.id, text)}
                placeholder="Type your private answer here..."
              />
            )}
          </View>
        ))}

        {/* Submit Button */}
        <TouchableOpacity onPress = {() => {props.navigation.navigate("Map")}} style={styles.submitButton}>
          <Text style={styles.submitButtonText}>Submit</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingBottom: 40,
  },
  title: {
    fontFamily: 'HappyChicken',
    fontSize: 24,
    marginBottom: 8,
    textAlign: 'center',
    paddingTop: 50
  },
  subtitle: {
    fontFamily: 'Summery',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 16
  },
  separator: {
    height: 1,
    marginVertical: 16
  },
  sectionSeparator: {
    height: 1,
    marginVertical: 24
  },
  sectionTitle: {
    fontFamily: 'HappyChicken',
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 8
  },
  questionContainer: {
    marginBottom: 24
  },
  questionText: {
    fontFamily: 'Summery',
    fontSize: 16,
    marginBottom: 8
  },
  input: {
    backgroundColor: 'white',
    fontFamily: 'Summery',
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    minHeight: 40,
    maxHeight: 200,
    textAlignVertical: 'top'
  },
  answerButton: {
    padding: 12,
    borderRadius: 8,
    alignItems: 'center'
  },
  answerButtonText: {
    fontFamily: 'HappyChicken',
    fontSize: 16
  },
  arrow: {
    position: "absolute",
    top: 65,
    left: 10,
  },
  backButton: {
    position: 'absolute',
    top: 65,
    left: 30,
    zIndex: 1,
  },
  backImage: {
    width: 50,
    height: 50,
    left: -10,
    top: 40,
  },
  submitButton: {
    backgroundColor: '#f09e9f',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  submitButtonText: {
    color: 'white',
    fontFamily: 'HappyChicken',
    fontSize: 18,
  },
  formType: {
    position: "absolute",
    resizeMode: "contain",
    height: 43,
  },
});

export default ReportFormScreen;