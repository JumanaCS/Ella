import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import NavBarComp from "../components/NavBarComp";
import * as Font from 'expo-font';

const PhoneScreen = (props) => {
  

  return (
    <View>

      <Image style={styles.image} source={require('../../assets/phonecall.png')} />

      <TouchableOpacity onPress = {() => {props.navigation.navigate("Map")}}>
        <Image style = {styles.button} ></Image>
      </TouchableOpacity>

    </View>
  );
};

const styles = StyleSheet.create({
  image: {
    position: "absolute",
    resizeMode: "contain",
    width: 400,
    top: -978,
  },
  button: {
    position: "absolute",
    width: 80,
    height: 80,
    top: 695,
    left: 40,
    borderRadius: 40,
  }
});

export default PhoneScreen;