import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import NavBarComp from "../components/NavBarComp";
import * as Font from 'expo-font';

const HomeScreen = (props) => {
  const [isWriting, setIsWriting] = useState(false);
  const [journalEntry, setJournalEntry] = useState('');
  const [entries, setEntries] = useState([]);
  const [fontsLoaded, setFontsLoaded] = useState(false);

  useEffect(() => {
    const loadAppFonts = async () => {
      try {
        await Font.loadAsync({
          'HappyChicken': require('../../assets/fonts/Happy_Chicken.ttf'),
          'Summery': require('../../assets/fonts/Summary_Notes.ttf')
        });
        setFontsLoaded(true);
      } catch (error) {
        console.error('Error loading fonts:', error);
      }
    };

    loadAppFonts();
  }, []);

  const handleAddEntry = () => {
    if (journalEntry.trim()) {
      setEntries([...entries, journalEntry]);
      setJournalEntry('');
      setIsWriting(false);
    }
  };

  if (!fontsLoaded) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: '#fef8eb'}]}>
        <Text>Loading app...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: '#fef8eb'}]}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: '#9b8cb1'}]}>Journal Entries</Text>
          <View style={styles.divider} />
          
          {!isWriting ? (
            <TouchableOpacity 
              style={[styles.addButton, { backgroundColor: '#9b8cb1'}]}
              onPress={() => setIsWriting(true)}
            >
              <Text style={styles.addButtonText}>New Journal Entry</Text>
            </TouchableOpacity>
          ) : (
            <View style={[styles.entryContainer, { backgroundColor: 'white' }]}>
              <TextInput
                style={[styles.entryInput, { 
                  color: '#333',
                  borderColor: '#ddd',
                  backgroundColor: 'white'
                }]}
                multiline
                placeholder="Write your journal entry here..."
                placeholderTextColor="#999" 
                value={journalEntry}
                onChangeText={setJournalEntry}
                textAlignVertical="top"
              />
              <View style={styles.buttonContainer}>
                <TouchableOpacity 
                  style={[styles.actionButton, { 
                    backgroundColor: '#ddc3e3' 
                  }]}
                  onPress={() => {
                    setIsWriting(false);
                    setJournalEntry('');
                  }}
                >
                  <Text style={[styles.actionButtonText, { 
                    color: 'white'
                  }]}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.actionButton, { 
                    backgroundColor: '#9b8cb1'
                  }]}
                  onPress={handleAddEntry}
                >
                  <Text style={[styles.actionButtonText, { 
                    color: 'white'
                  }]}>Save</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {entries.map((entry, index) => (
            <View key={index} style={[styles.savedEntry, { 
              backgroundColor: 'white' 
            }]}>
              <Text style={[styles.savedEntryText, { 
                color: '#9b8cb1'
              }]}>{entry}</Text>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { 
            color: '#9b8cb1' 
          }]}>My Reports</Text>
          <View style={styles.divider} />
          <View style={styles.centeredTextContainer}>
            <Text style={[styles.reportText, { 
              color: '#666' 
            }]}>Personal reports will appear here.</Text>
            <Text style={[styles.reportText, { 
              color: '#666' 
            }]}>These will be public.</Text>
            <Text style={[styles.reportText, { 
              color: '#666' 
            }]}>Add a report by navigating to the map screen.</Text>
          </View>
        </View>
      </ScrollView>

      <NavBarComp isMap="false" isPersonal="true" isResources="false"
                  navBarPosition = {styles.navBarPosition} barRevised = {styles.barRevised}
                  onPressMap={() => {props.navigation.navigate("Map")}}
                  onPressResources={() => {props.navigation.navigate("Resources")}}/>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
  },
  scrollContainer: {
    padding: 20,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 50,
    marginBottom: 15,
    fontFamily: 'HappyChicken',
  },
  divider: {
    borderBottomColor: '#ddd',
    borderBottomWidth: 1,
    marginBottom: 15,
  },
  addButton: {
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: {
    color: 'white',
    fontSize: 16,
    fontFamily: 'HappyChicken',
  },
  entryContainer: {
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  entryInput: {
    minHeight: 150,
    fontSize: 16,
    borderWidth: 1,
    borderRadius: 6,
    padding: 10,
    marginBottom: 15,
    fontFamily: 'Summery',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    padding: 12,
    borderRadius: 6,
    width: '48%',
    alignItems: 'center',
  },
  actionButtonText: {
    fontFamily: 'HappyChicken',
    fontSize: 16,
  },
  savedEntry: {
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  savedEntryText: {
    fontSize: 16,
    fontFamily: 'Summery',
  },
  reportText: {
    fontSize: 16,
    marginBottom: 5,
    textAlign: 'center',
    fontFamily: 'Summery',
  },
  centeredTextContainer: {
    alignItems: 'center',
  },
  navBarPosition:{
    bottom: 38
  },
  barRevised: {
    top: -2
  }
});

export default HomeScreen;