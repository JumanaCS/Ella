import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Image } from 'react-native';
import * as Font from 'expo-font';

const ResourcesScreen = ({ navigation }) => {
  const [emergencyContact, setEmergencyContact] = useState({
    name: '',
    phone: '',
    message: '',
    checkInTime: '00:00'
  });
  
  const [selectedStation, setSelectedStation] = useState(null);
  const [timeInputVisible, setTimeInputVisible] = useState(false);
  const [tempTime, setTempTime] = useState('');
  const [fontsLoaded, setFontsLoaded] = useState(false);

  React.useEffect(() => {
    const loadAppFonts = async () => {
      try {
        await Font.loadAsync({
          'HappyChicken': require('../../assets/fonts/Happy_Chicken.ttf'),
          'Summery': require('../../assets/fonts/Summary_Notes.ttf')
        });
        setFontsLoaded(true);
      } catch (error) {
        console.error('Error loading fonts:', error);
      }
    };

    loadAppFonts();
  }, []);

  const policeStations = [
    { id: 1, name: 'UNO Police Department' },
    { id: 2, name: 'NOPD - Second District Station' },
    { id: 3, name: 'New Orleans Police Department' }
  ];

  const supportLines = [
    { name: 'National Sexual Assault Hotline', number: '1-800-656-4673' },
    { name: 'National Domestic Violence Hotline', number: '1-800-799-7233' },
    { name: 'Suicide and Crisis Lifeline', number: '988' },
    { name: 'Substance Abuse', number: '1-800-662-4357' }
  ];

  const localSupportLines = [
    { name: 'Women with a Vision (WWAV) ', number: '(504) 302-8822' },
    { name: 'Sexual Trauma Awareness (STAR)', number: '(855) 435-7827' },
    { name: 'New Orleans Women Shelter', number: '(504) 522-9340' }
  ];

  const supportGroups = [
    { name: 'Local AA Meeting Line', number: '(225) 930-0026' },
    { name: 'NOLA Women Group', number: '(504) 608-7280' },
  ];

  const handleTimePress = () => {
    setTimeInputVisible(true);
  };

  const handleTimeSubmit = () => {
    if (/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(tempTime)) {
      setEmergencyContact({...emergencyContact, checkInTime: tempTime});
    }
    setTimeInputVisible(false);
    setTempTime('');
  };

  if (!fontsLoaded) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: '#fef8e9' }]}>
        <Text>Loading app...</Text>
      </View>
    );
  }

  return (
    <View style={styles.mainContainer}>
      <ScrollView style={[styles.container, { backgroundColor: '#fef8e9' }]}>
        <View style={styles.topPadding}></View>

        
        {/* Emergency Check-in Box */}
        <View style={styles.box}>
          <Text style={[styles.boxTitle, { color: '#9b8cb1' }]}>Emergency Check-in</Text>
          
          <TextInput
            style={[styles.input, { 
              borderColor: '#ddd', 
              color: '#333',
              placeholderTextColor: '#999' 
            }]}
            placeholder="Emergency contact's name"
            value={emergencyContact.name}
            onChangeText={(text) => setEmergencyContact({...emergencyContact, name: text})}
          />
          
          <TextInput
            style={[styles.input2, { 
              borderColor: '#ddd', 
              color: '#333',
              placeholderTextColor: '#999' 
            }]}
            placeholder="Emergency contact's Phone number"
            value={emergencyContact.phone}
            onChangeText={(text) => setEmergencyContact({...emergencyContact, phone: text})}
            keyboardType="phone-pad"
          />
          
          <TextInput
            style={[styles.input, { 
              borderColor: '#ddd', 
              color: '#333',
              placeholderTextColor: '#999' 
            }]}
            placeholder="Message if not checked in"
            value={emergencyContact.message}
            onChangeText={(text) => setEmergencyContact({...emergencyContact, message: text})}
            multiline
          />
          
          <Text style={[styles.label, { color: '#555' }]}>Time of check in</Text>
          
          {timeInputVisible ? (
            <View style={styles.timeInputContainer}>
              <TextInput
                style={[styles.timeInput, { 
                  borderColor: '#ddd', 
                  color: '#333' 
                }]}
                placeholder="HH:MM"
                value={tempTime}
                onChangeText={setTempTime}
                keyboardType="numbers-and-punctuation"
              />
              <TouchableOpacity 
                style={[styles.timeSubmitButton, { backgroundColor: '#4CAF50' }]} 
                onPress={handleTimeSubmit}
              >
                <Text style={[styles.timeSubmitText, { color: 'white' }]}>✓</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity 
              style={[styles.timerDisplay, { 
                borderColor: '#ddd', 
                backgroundColor: '#f9f9f9' 
              }]} 
              onPress={handleTimePress}
            >
              <Text style={[styles.timerText, { color: '#333' }]}>{emergencyContact.checkInTime}</Text>
            </TouchableOpacity>
          )}
        </View>
        
        {/* Police Stations Box */}
        <View style={styles.box}>
          <Text style={[styles.boxTitle, { color: '#9b8cb1' }]}>Local Police Stations</Text>
          
          <TouchableOpacity 
            style={[styles.setEmergencyButton, { backgroundColor: '#9b8cb1' }]}
          >
            <Text style={[styles.setEmergencyButtonText, { color: 'white' }]}>Set as emergency</Text>
          </TouchableOpacity>
          
          <View style={styles.stationButtonsContainer}>
            {policeStations.map(station => (
              <TouchableOpacity
                key={station.id}
                style={[
                  styles.stationButton,
                  selectedStation === station.id && { 
                    backgroundColor: '#ddc3e3', 
                    borderColor: '#ddc3e3' 
                  }
                ]}
                onPress={() => setSelectedStation(station.id)}
              >
                <Text style={[
                  styles.stationButtonText,
                  selectedStation === station.id && { color: 'white' }
                ]}>
                  {station.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        {/* Resources Box */}
        <View style={styles.box}>
          <Text style={[styles.boxTitle, { color: '#9b8cb1' }]}>Resources</Text>
          <View style={[styles.divider, { borderBottomColor: '#ddd' }]} />
          
          {/* Support Lines Section */}
          <Text style={[styles.subHeader, { color: '#9b8cb1' }]}>Support Lines</Text>
          <View style={[styles.resourceHeader, { borderBottomColor: '#eee' }]}>
            <Text style={[styles.resourceHeaderText, { color: '#555' }]}>Name</Text>
            <Text style={[styles.resourceHeaderText, { color: '#555' }]}>Phone #</Text>
          </View>
          {supportLines.map((resource, index) => (
            <View key={`support-${index}`} style={[styles.resourceRow, { borderBottomColor: '#f0f0f0' }]}>
              <Text style={[styles.resourceName, { color: '#333' }]}>{resource.name}</Text>
              <Text style={[styles.resourceNumber, { color: '#666' }]}>{resource.number}</Text>
            </View>
          ))}
          
          {/* Local Support Lines Section */}
          <Text style={[styles.subHeader, { color: '#9b8cb1' }]}>Local Support Lines</Text>
          <View style={[styles.resourceHeader, { borderBottomColor: '#eee' }]}>
            <Text style={[styles.resourceHeaderText, { color: '#555' }]}>Name</Text>
            <Text style={[styles.resourceHeaderText, { color: '#555' }]}>Phone #</Text>
          </View>
          {localSupportLines.map((resource, index) => (
            <View key={`local-${index}`} style={[styles.resourceRow, { borderBottomColor: '#f0f0f0' }]}>
              <Text style={[styles.resourceName, { color: '#333' }]}>{resource.name}</Text>
              <Text style={[styles.resourceNumber, { color: '#666' }]}>{resource.number}</Text>
            </View>
          ))}
          
          {/* Support Groups Section */}
          <Text style={[styles.subHeader, { color: '#9b8cb1' }]}>Support Groups</Text>
          <View style={[styles.resourceHeader, { borderBottomColor: '#eee' }]}>
            <Text style={[styles.resourceHeaderText, { color: '#555' }]}>Name</Text>
            <Text style={[styles.resourceHeaderText, { color: '#555' }]}>Phone #</Text>
          </View>
          {supportGroups.map((resource, index) => (
            <View key={`group-${index}`} style={[styles.resourceRow, { borderBottomColor: '#f0f0f0' }]}>
              <Text style={[styles.resourceName, { color: '#333' }]}>{resource.name}</Text>
              <Text style={[styles.resourceNumber, { color: '#666' }]}>{resource.number}</Text>
            </View>
          ))}
        </View>
        
        <View style={styles.bottomPadding}></View>
      </ScrollView>
      
      {/* Floating NavBar */}
      <View style={styles.navBarContainer}>
        <View style={styles.navBar}>
          <TouchableOpacity 
            style={styles.navButton}
            onPress={() => navigation.navigate('Personal')}
          >
            <Image 
              source={require('../../assets/personalno.png')} 
              style={styles.navIcon} 
              
            />
            
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.navButton}
            onPress={() => navigation.navigate('Map')}
          >
            <Image 
              source={require('../../assets/mapno.png')} 
              style={styles.navIcon} 
            />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.navButton}
            onPress={() => navigation.navigate('Resources')}
          >
            <Image 
              source={require('../../assets/resyes.png')} 
              style={styles.navIcon} 
            />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: '#fef8e9',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
    padding: 20,
  },
  topPadding: {
    height: 50,
  },
  bottomPadding: {
    height: 100,
  },
  box: {
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    backgroundColor: 'white',
  },
  boxTitle: {
    fontSize: 20,
    marginBottom: 15,
    fontFamily: 'HappyChicken',
  },
  divider: {
    borderBottomWidth: 1,
    marginBottom: 15,
  },
  input2:{
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
    fontSize: 16,
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
    fontSize: 16,
    fontFamily: 'Summery',
  },
  label: {
    fontSize: 16,
    marginBottom: 10,
    fontFamily: 'Summery',
  },
  timerDisplay: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  timerText: {
    fontSize: 16,
    fontFamily: 'HappyChicken',
  },
  timeInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timeInput: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  timeSubmitButton: {
    marginLeft: 10,
    borderRadius: 8,
    padding: 12,
  },
  timeSubmitText: {
    fontSize: 16,
    fontFamily: 'Summery',
  },
  setEmergencyButton: {
    borderRadius: 8,
    padding: 15,
    alignItems: 'center',
    marginBottom: 15,
  },
  setEmergencyButtonText: {
    fontSize: 16,
    fontFamily: 'HappyChicken',
  },
  stationButtonsContainer: {},
  stationButton: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 10,
    backgroundColor: '#f9f9f9',
    borderColor: '#ddd',
  },
  stationButtonText: {
    fontSize: 14,
    fontFamily: 'Summery',
  },
  subHeader: {
    fontSize: 18,
    marginBottom: 15,
    fontFamily: 'Summery',
  },
  resourceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    paddingBottom: 5,
    borderBottomWidth: 1,
  },
  resourceHeaderText: {
    fontSize: 16,
    fontFamily: 'Summery',
  },
  resourceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  resourceName: {
    fontSize: 15,
    fontFamily: 'Summery',
  },
  resourceNumber: {
    fontSize: 15,
  },
  formType: {
    position: "absolute",
    resizeMode: "contain",
    height: 43,
  },
  // NavBar Styles
  
  navBarContainer: {
    position: 'absolute',
    bottom: 42,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  navBar: {
    flexDirection: 'row',
    backgroundColor: '#9b8cb1',
    borderRadius: 15,
    paddingVertical: 2,
    paddingHorizontal: 20,
    width: '94%',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  navButton: {
    alignItems: 'center',
    padding: 5,
  },
  navIcon: {
    width: 50,
    height: 50,
    resizeMode: 'contain',
    margin: 3,
  },
  navText: {
    fontSize: 12,
    color: 'white',
  },
  activeNavText: {
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
  bar: {
    position: "absolute",
    height: 70,
    width: 340,
    top: 740,
    left: 25,
    borderRadius: 15,
    backgroundColor: '#9b8cb1',
},
});

export default ResourcesScreen;