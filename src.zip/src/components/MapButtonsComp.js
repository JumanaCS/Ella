import React from "react";
import { Text, StyleSheet, View, Image, TouchableOpacity } from "react-native";

//bottom bar (rectangle), "closet and outfits" button, "camera" button, "profile" button

const MapButtonsComp = (props) => {

  return (
    
  <View>

        {props.isHeat === "true"
        ? <TouchableOpacity onPress={ props.onPressGoMap }>
            <Image style={styles.image} source={require('../../assets/heaticon.png')} />
            </TouchableOpacity>
        : null
        }
        {props.isHeat === "false"
        ? <TouchableOpacity onPress={ props.onPressGoHeat }>
            <Image style={styles.image} source={require('../../assets/mapicon.png')} />
            </TouchableOpacity>
        : null
        }

        <Image style={[styles.imagelocation]} source={require('../../assets/setlocation.png')} />

  </View>

  );
};


const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderTopWidth: 2,
        paddingVertical: 10,
        paddingBottom: 30,
        marginTop: 20,
        gap: 70,
        borderColor: "#193625",
        backgroundColor: '#DAE7E0'
    },
    camera: {
        height: 50,
        width: 50,
    },
    image: {
        position: "absolute",
        resizeMode: "contain",
        width: 55,
        height: 55,
        top: 670,
        left: 25,
    },
    imagelocation: {
        position: "absolute",
        resizeMode: "contain",
        width: 55,
        height: 55,
        top: 610,
        left: 25,
    },
    bar: {
        position: "absolute",
        resizeMode: "contain",
        width: 400,
        right: 0
    }
});

export default MapButtonsComp;
