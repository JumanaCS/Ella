import React, {useState} from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity, TextInput } from "react-native";
import NavBarComp from "../components/NavBarComp";
import TopBarComp from "../components/TopBarComp";
import MapButtonsComp from "../components/MapButtonsComp";

const DEFAULT_SCREEN_STATE = "defaultScreen";
const HEAT_SCREEN_STATE = "heatScreen";
const LOCATION_SCREEN_STATE = "entryScreen";
const PINNED_SCREEN_STATE = "pinnedScreen";

var whatToDisplay;

const MapScreen = (props) => {

  const [screenState, setScreenState] = useState(DEFAULT_SCREEN_STATE)

  switch(screenState){

    case DEFAULT_SCREEN_STATE:
    whatToDisplay = 

    <View style={styles.flexBox}>

      <Image style={styles.map} source={require('../../assets/mapdefault.png')} />

      <TopBarComp phoneNav = {() => {props.navigation.navigate("Phone")}}></TopBarComp>

      <MapButtonsComp isHeat="false" onPressGoHeat={ () => {setScreenState(HEAT_SCREEN_STATE)}}/>

      <NavBarComp isMap="true" isPersonal="false" isResources="false"
        navBarPosition = {styles.navBarPosition}
                  onPressPersonal={() => {props.navigation.navigate("Personal")}}
                  onPressResources={() => {props.navigation.navigate("Resources")}}/>


      <TouchableOpacity onPress={ () => {setScreenState(LOCATION_SCREEN_STATE)}}>
        <Image style={styles.reportButton} source={require('../../assets/report.png')} />
      </TouchableOpacity>

    </View>

    break;

    case HEAT_SCREEN_STATE:
    whatToDisplay = 

    <View style={styles.flexBox}>

      <Image style={styles.map} source={require('../../assets/heatmap.png')} />

      <TopBarComp phoneNav = {() => {props.navigation.navigate("Phone")}}></TopBarComp>

      <MapButtonsComp isHeat="true" onPressGoMap={ () => {setScreenState(DEFAULT_SCREEN_STATE)}}/>

      <NavBarComp isMap="true" isPersonal="false" isResources="false"
        navBarPosition = {styles.navBarPosition}
                  onPressPersonal={() => {props.navigation.navigate("Personal")}}
                  onPressResources={() => {props.navigation.navigate("Resources")}}/>


      <TouchableOpacity onPress={ () => {setScreenState(LOCATION_SCREEN_STATE)}}>
        <Image style={styles.reportButton} source={require('../../assets/report.png')} />
      </TouchableOpacity>

    </View>

    break;

    case LOCATION_SCREEN_STATE:
    whatToDisplay = 

    <View style={styles.flexBox}>

      <TouchableOpacity onPress={ () => {setScreenState(PINNED_SCREEN_STATE)}}>
        <Image style={styles.map} source={require('../../assets/mapblank.png')} />
      </TouchableOpacity>

      <TopBarComp phoneNav = {() => {props.navigation.navigate("Phone")}}></TopBarComp>

      <MapButtonsComp isHeat="false"/>

      <NavBarComp isMap="true" isPersonal="false" isResources="false"
        navBarPosition = {styles.navBarPosition}
                  onPressPersonal={() => {props.navigation.navigate("Personal")}}
                  onPressResources={() => {props.navigation.navigate("Resources")}}/>

      <Image style={styles.pingButton} source={require('../../assets/ping.png')} />

      
      

    </View>

    break;

    case PINNED_SCREEN_STATE:
    whatToDisplay = 

    <View style={styles.flexBox}>

      <TouchableOpacity onPress={ () => {props.navigation.navigate("Report")}}>
        <Image style={styles.map} source={require('../../assets/pinned.png')} />
      </TouchableOpacity>

      <TopBarComp phoneNav = {() => {props.navigation.navigate("Phone")}}></TopBarComp> 

      <MapButtonsComp isHeat="false"/>

      <NavBarComp isMap="true" isPersonal="false" isResources="false"
        navBarPosition = {styles.navBarPosition}
                  onPressPersonal={() => {props.navigation.navigate("Personal")}}
                  onPressResources={() => {props.navigation.navigate("Resources")}}/>

      <Image style={styles.pingButton} source={require('../../assets/ping.png')} />

      
      

    </View>

    break;


  }

  return whatToDisplay;
};

const styles = StyleSheet.create({
  text: {
    fontSize: 30,
    top: 60,
  },
  navBarPosition: {
    top: 704,
  },
  flexBox: {
    flex: 1
  },
  reportButton: {
    position: "absolute",
    resizeMode: "contain",
    fontSize: 30,
    width: 210,
    top: 525,
    left: 95,
  },
  pingButton: {
    position: "absolute",
    resizeMode: "contain",
    fontSize: 30,
    width: 210,
    top: 635,
    left: 95,
  },
  map:{
    position: "absolute",
    resizeMode: "contain",
    width: 400,
    top: -700,
    
  },
  textBox: {
    position: "absolute",
    top: 150,
    margin: 20,
    height: 50,
    width: 350,
    borderRadius: 7,
    backgroundColor: "lightgrey"
  }

});

export default MapScreen;
