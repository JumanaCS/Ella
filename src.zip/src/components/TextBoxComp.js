import React, {useState} from "react";
import { Text, StyleSheet, View, Image, TouchableOpacity, TextInput } from "react-native";

//bottom bar (rectangle), "closet and outfits" button, "camera" button, "profile" button



const TextBoxComp = (props) => {

    const [text, setText] = useState('');
  const [height, setHeight] = useState(40);

  return (
    
    <View style={styles.container}>
        <TextInput
            style={[styles.textInput, { height: Math.max(40, height) }]}
            multiline={true}
            onChangeText={(newText) => setText(newText)}
            onContentSizeChange={(event) => {
            setHeight(event.nativeEvent.contentSize.height);
            }}
            value={text}
            placeholder="placeholder text..."
        />
    </View>

  );
};


const styles = StyleSheet.create({
    container: {
        padding: 10,
        position: "absolute"
      },
    camera: {
        height: 50,
        width: 50,
    },
    image: {
        position: "absolute",
        resizeMode: "contain",
        width: 55,
        height: 55,
        top: 670,
        left: 25,
    },
    imagelocation: {
        position: "absolute",
        resizeMode: "contain",
        width: 55,
        height: 55,
        top: 610,
        left: 25,
    },
    bar: {
        position: "absolute",
        resizeMode: "contain",
        width: 400,
        right: 0
    }
});

export default TextBoxComp;
