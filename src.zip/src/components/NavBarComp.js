import React from "react";
import { Text, StyleSheet, View, Image, TouchableOpacity } from "react-native";

//bottom bar (rectangle), "closet and outfits" button, "camera" button, "profile" button

const NavBarComp = (props) => {

  return (

    <View>

    <Image style={[styles.bar, props.barRevised]}/>

        <View style={[styles.container, props.navBarPosition]}>

        {props.isPersonal === "true"
        ? <TouchableOpacity onPress={ props.onPressPersonal }>
            <Image style={styles.image} source={require('../../assets/personalyes.png')} />
            </TouchableOpacity>
        : null
        }
        {props.isPersonal === "false"
        ? <TouchableOpacity onPress={ props.onPressPersonal }>
            <Image style={styles.image} source={require('../../assets/personalno.png')} />
            </TouchableOpacity>
        : null
        }
        
        {props.isMap === "true"
        ? <TouchableOpacity onPress={ props.onPressMap }>
            <Image style={styles.image} source={require('../../assets/mapyes.png')} />
            </TouchableOpacity>
        : null
        }
        {props.isMap === "false"
        ? <TouchableOpacity onPress={ props.onPressMap }>
            <Image style={styles.image} source={require('../../assets/mapno.png')} />
            </TouchableOpacity>
        : null
        }
        
        {props.isResources === "true"
        ? <TouchableOpacity onPress={ props.onPressResources }>
            <Image style={styles.image} source={require('../../assets/resyes.png')} />
            </TouchableOpacity>
        : null
        }
        {props.isResources === "false"
        ? <TouchableOpacity onPress={ props.onPressResources }>
            <Image style={styles.image} source={require('../../assets/resno.png')} />
            </TouchableOpacity>
        : null
        }


        </View>

    </View>
    
  

  );
};


const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'center',
        paddingVertical: 10,
        paddingBottom: 30,
        marginTop: 20,
        gap: 60,
        
    },
    bar: {
        position: "absolute",
        height: 70,
        width: 370,
        top: 740,
        left: 11.5,
        borderRadius: 15,
        backgroundColor: '#9b8cb1',
    },
    image: {
        resizeMode: "contain",
        height: 50,
        width: 50,
        top: 16
    },
});

export default NavBarComp;
