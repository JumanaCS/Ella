import React, {useState} from "react";
import { Text, StyleSheet, View, Image, TouchableOpacity, FlatList } from "react-native";
import NavBarComp from "../components/NavBarComp";
import TopBarComp from "../components/TopBarComp";



const DEFAULT_SCREEN_STATE = "defaultScreen";
const ENTRY_SCREEN_STATE = "entryScreen";



const PersonalScreen = (props) => {

  const [screenState, setScreenState] = useState(DEFAULT_SCREEN_STATE)


    switch(screenState){
      case DEFAULT_SCREEN_STATE:
        whatToDisplay =

        <View style={styles.flexBox}>

          <Text style={styles.titleText}>Personal Screen</Text>

          <Text style={styles.journalText}>Journal Entries</Text>

          <TouchableOpacity onPress={ () => {setScreenState(ENTRY_SCREEN_STATE)}}>
            <Image style={styles.addButton} source={require('../../assets/favicon.png')}/>
          </TouchableOpacity>


          <NavBarComp isMap="false" isPersonal="true" isResources="false"
          navBarPosition = {styles.navBarPosition}
                  onPressMap={() => {props.navigation.navigate("Map")}}
                  onPressResources={() => {props.navigation.navigate("Resources")}}/>

        </View>
        break;

      case ENTRY_SCREEN_STATE:
        whatToDisplay =

        <View style={styles.flexBox}>

          <Text style={styles.titleText}>Personal Screen</Text>

          <Text style={styles.journalText}>Journal Entries</Text>

          <TouchableOpacity onPress={ () => {setScreenState(ENTRY_SCREEN_STATE)}}>
            <Image style={styles.addButton} source={require('../../assets/favicon.png')}/>
          </TouchableOpacity>

          <Text style={styles.entry}>Entry #1 - 03/29/2025</Text>
          
          <NavBarComp personalIconBox={{opacity: 1}} navBarPosition = {styles.navBarPosition}
                      onPressMap={() => {props.navigation.navigate("Map")}}
                      onPressResources={() => {props.navigation.navigate("Resources")}}/>

        </View>
        break;
    }
    
    
        


  return whatToDisplay;
};

const styles = StyleSheet.create({
  titleText: {
    fontSize: 30,
    top: 60,
  },
  journalText: {
    fontSize: 30,
    top: 90,
    padding: 0,
    position: 'left',
    padding: 10,
  },
  addButton: {
    position: 'absolute',
    top: 38,
    left: 325,
  },
  navBarPosition: {
    top: 648,
  },
  entry: {
    position: "absolute",
    top: 200,
    left: 15,
    borderWidth: 2,
    padding: 10,
    paddingRight: 200
  },
  flexBox: {
    flex: 1,
  },
  
});

export default PersonalScreen;
